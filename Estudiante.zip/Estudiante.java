//Andersson cartagena hidalgo
//ficha 2821728
import java.util.ArrayList;
import java.util.Scanner;

public class Estudiante { // se crea una clase estidiante con tres objetos

    private int identificacion;
    private String Nombre;
    private String Email;

    public Estudiante(int identificacion, String Nombre, String Email) {// se crea el constructor de la clase estableciendo valores predeterminados
        this.identificacion = identificacion;
        this.Nombre = Nombre;
        this.Email = Email;
    }

    public int getIdentificacion() {// se crean los setters y getters para llamar el valor de la variable y asignar valores nuevos si es el caso 
        return identificacion;
    }

    public void setIdentificacion(int identificacion) {
        this.identificacion = identificacion;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String nombre) {
        Nombre = nombre;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    @Override
    public String toString() {// se muestra el objeto estudiante como una cadena de texto
        return  "Estudiante{" +
        "identificacion=" + identificacion +
        ", nombre='" + Nombre + '\'' +
        ", email='" + Email + '\'' +
        '}';
    }

    public class Principal {// se crea la clase principal 
        private static Scanner scanner = new Scanner(System.in);
        private static ArrayList<Estudiante> estudiantes = new ArrayList<>();// se crea un arraylist para almacenar los objetos de la clase Estudiante

        public static void main(String[] args) {
            
            System.out.println("Ingrese el número de estudiantes que desea registrar: ");// se pide al usuario  ingresar la cantidad de registros deseados

            int n = scanner.nextInt();// los registros se guardan en la variable n

            for (int i = 0; i <= n; i++) {//se ejecuta el ciclo n veces solicitando la información
                System.out.println("Ingrese la identificacion: ");
                int identificacion = scanner.nextInt();
                System.out.print("Nombre: ");
                String nombre = scanner.next();
                System.out.print("Email: ");
                String email = scanner.next();
                estudiantes.add(new Estudiante(identificacion, nombre, email));//se agraga el nuevo objeto Estudiante a estudiantes
            }

            int opciones = 1;
            while (opciones != 4) {//se pide al usuario elegir la opcion a consultar
                System.out.println("1. ID del estudiante: ");
                System.out.println("2. Actualizar los datos: ");
                System.out.println("3. Imprimir estudiantes: ");
                System.out.println("4. Desea salir?: ");
                System.out.println("Elija una opción: ");

                if (opciones == 1) {//si la opcion es 1, se guarda el valor ingresado en iddelestudiante y asi con las otras opciones
                    iddelestudiate(estudiantes);
                } else if (opciones == 2) {
                    Actualizarlosdatos(estudiantes);
                } else if (opciones == 3) {
                    imprimirestudiantes(estudiantes);
                } else if (opciones == 4) {
                    System.out.println("Ha salido");
                } else {
                    System.out.println("Ingrese una de las cuatro opciones validas: ");
                }
            }
        }

        private static void iddelestudiate(ArrayList<Estudiante> estudiantes) {
            System.out.println("Ingrese ID del estudiante: ");
            int ID =scanner.nextInt();
            Estudiante estudiantelocalizado = null;
            for (Estudiante estudiante : estudiantes) {
                if (estudiante.getIdentificacion() == ID) {
                    estudiantelocalizado = estudiante;
                    break;
                }
            }

            if (estudiantelocalizado != null) {
                System.out.println("Informe del aprendiz: ");
                System.out.println(estudiantelocalizado);
            } else {
                System.out.println("No se encontró información " + ID);
            }
        }

        private static void Actualizarlosdatos(ArrayList<Estudiante> estudiantes) {
            System.out.println("Ingrese identificacion a actualizar: ");
            int ID = scanner.nextInt();
            Estudiante estudiantelocalizado = null;
            for (Estudiante estudiante : estudiantes) {
                if (estudiante.getIdentificacion() == ID) {
                    estudiantelocalizado = estudiante;
                }
            }
            if (estudiantelocalizado != null) {
                System.out.println("nombre: ");
                String nuevoNombre = scanner.next();
                System.out.println("identificación: ");
                int nuevaIdentificacion = scanner.nextInt();
                estudiantelocalizado.setNombre(nuevoNombre);
                estudiantelocalizado.setIdentificacion(nuevaIdentificacion);
                System.out.println("Actualizado: ");
                System.out.println(estudiantelocalizado);
            }
    
        }
        private static void imprimirestudiantes(ArrayList<Estudiante> estudiantes) {
            for (Estudiante estudiante : estudiantes) {
                System.out.println(estudiante);
            }
        }
    }
}